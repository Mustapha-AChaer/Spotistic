import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-artist-page',
  templateUrl: './artist-page.page.html',
  styleUrls: ['./artist-page.page.scss'],
})
export class ArtistPagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

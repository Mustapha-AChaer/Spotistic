# spotistic
Spotistic is an Up and coming app that allows you to search for your favirote aritst and check out there album list and song list

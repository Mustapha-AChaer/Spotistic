<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');

include("./createAccount/connection.php");

$payload = json_decode(file_get_contents("php://input"));
$artistName = json_encode($payload->artistName);
//echo json_decode($artistName);
// print json_decode($artistName);
$query = "SELECT albums.albumName FROM albums, singers WHERE singers.name = '" . json_decode($artistName) . "'  AND albums.singersID = singers.singersID;";
$stmt = $connection->prepare($query);
$stmt->execute();
$result = $stmt->get_result();

$temp_array = [];

while ($row = $result->fetch_assoc()) {
    $temp_array[] = $row;
}

$json = json_encode($temp_array);

print $json;

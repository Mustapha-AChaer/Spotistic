<?php
header('Access-Control-Allow-Origin:  *');
header('Access-Control-Allow-Headers: Content-Type');


include("connection.php");

$payload = json_decode(file_get_contents("php://input"));
$email = json_encode($payload->email);
$password = json_encode($payload->password);

$query = "SELECT password FROM users WHERE email='" . json_decode($email) . "'";
$stmt = $connection->prepare($query);
$stmt->execute();
$result = $stmt->get_result();

$temp_array = [];
$respone = [];
$response['result'] = null;

while ($row = $result->fetch_assoc()) {
    $temp_array[] = $row;
}
if (isset($temp_array[0]['password']) && $temp_array[0]['password'] == hash("sha256", json_decode($password))) {
    $response['result'] = true;
    print json_encode($response["result"]);
} else {
    $response['result'] = false;
    print json_encode($response["result"]);
}

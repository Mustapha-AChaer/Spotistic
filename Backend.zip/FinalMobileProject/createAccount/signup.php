<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');

include("connection.php");

$payload = json_decode(file_get_contents("php://input"));
$name = json_encode($payload->name);
$email = json_encode($payload->email);
$password = json_encode($payload->password);
$repassword = json_encode($payload->repass);

$newpass = null;
if (json_decode($name) != '' && json_decode($email) != '') {
    if (json_decode($password) == json_decode($repassword)) {
        // echo "hello";
        $newpass = json_decode($password);
        $newpass = hash("sha256", $newpass);
        //echo json_encode($newpass);
    } else {

        die("passwords not matching");
    }
}


$query = "SELECT email FROM users WHERE email='" . json_decode($email) . "'";
$stmt = $connection->prepare($query);
$stmt->execute();
$result = $stmt->get_result();

$temp_array = [];
while ($row = $result->fetch_assoc()) {
    $temp_array[] = $row;
}

if ($temp_array[0]['email'] == json_decode($email)) {
    echo json_encode("there already is an email");
} else {
    $mysql = $connection->prepare('INSERT INTO users(name, email, password, type) VALUES (?,?,?,?)');

    $type = "NORMAL";
    echo json_encode($payload->name);

    $mysql->bind_param("ssss", $payload->name, $payload->email, $newpass, $type);
    $mysql->execute();
    $mysql->close();
    $connection->close();
}

<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');

include("./createAccount/connection.php");

$payload = json_decode(file_get_contents("php://input"));
$albumName = json_encode($payload->albumName);
$query = "SELECT songs.songName FROM songs,albums WHERE albums.albumName = '" . json_decode($albumName) . "' AND albums.albumID = songs.albID";
$stmt = $connection->prepare($query);
$stmt->execute();
$result = $stmt->get_result();

$temp_array = [];

while ($row = $result->fetch_assoc()) {
    $temp_array[] = $row;
}

$json = json_encode($temp_array);

print $json;
